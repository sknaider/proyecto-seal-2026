#!/usr/bin/env bash
# ============================================================================
# run_granprix.sh — CapyTown Gran Prix: TODO con UN SOLO comando en RealVNC.
# ============================================================================
# AUTO-DETECTA el docker CONTENEDOR PRINCIPAL (no hace falta anotar IDs a mano
# ni editarlos cada vez que cambian tras reiniciar la Pi — los IDs de Docker
# son aleatorios en cada `docker run`). El bringup (chasis/IMU/LiDAR) sigue
# corriendo DIRECTO en la Pi (sh ros2_humble.sh), igual que tu Terminal 1
# original — no en docker.
#
# Si cámara/código/servo viven en contenedores DISTINTOS (no el mismo
# "principal"), fuerza cada uno así:
#   CAM_CONTAINER=xxxx MAIN_CONTAINER=yyyy SERVO_CONTAINER=zzzz bash run_granprix.sh
#
# Para DETENER todo:
#   tmux kill-session -t granprix
# ============================================================================

IMAGE_FILTER="${IMAGE_FILTER:-yahboomtechnology/ros-humble}"
SERVO_S1="${SERVO_S1:-20}"
SERVO_S2="${SERVO_S2:--55}"

WS_SETUP="source ~/yahboomcar_ws/install/setup.bash && source /opt/ros/humble/setup.bash"
SESSION="granprix"

set -u

if ! command -v tmux >/dev/null 2>&1; then
  echo "tmux no está instalado. Instálalo una vez con:"
  echo "    sudo apt-get update && sudo apt-get install -y tmux"
  exit 1
fi

# --- auto-detecta el contenedor PRINCIPAL: primero por nombre de imagen; si no
# hay match (tag distinto, etc.) cae al primer contenedor corriendo. Así el
# script no se rompe cuando el ID cambia entre reinicios de la Pi.
MAIN_AUTO="$(docker ps -q --filter "ancestor=${IMAGE_FILTER}" | head -n1)"
if [ -z "$MAIN_AUTO" ]; then
  MAIN_AUTO="$(docker ps -q | head -n1)"
fi
if [ -z "$MAIN_AUTO" ]; then
  echo "!!! No encuentro ningún contenedor Docker corriendo (docker ps)."
  echo "    Abre OTRA terminal en RealVNC, corre:  sh ~/ros2_humble.sh"
  echo "    y déjala abierta. Luego vuelve a correr:  bash ~/run_granprix.sh"
  exit 1
fi

CAM_CONTAINER="${CAM_CONTAINER:-$MAIN_AUTO}"
MAIN_CONTAINER="${MAIN_CONTAINER:-$MAIN_AUTO}"
SERVO_CONTAINER="${SERVO_CONTAINER:-$MAIN_AUTO}"

echo "==> Contenedor principal detectado: $MAIN_AUTO"
echo "    CAM=$CAM_CONTAINER  MAIN=$MAIN_CONTAINER  SERVO=$SERVO_CONTAINER"
echo "    (para forzar otro por rol: CAM_CONTAINER=xxx MAIN_CONTAINER=yyy SERVO_CONTAINER=zzz bash run_granprix.sh)"

# Reinicia limpio si ya había una corrida anterior abierta.
tmux kill-session -t "$SESSION" 2>/dev/null || true

echo "==> Lanzando CapyTown Gran Prix (sesión tmux '$SESSION')..."

# ---------------------------------------------------------------------------
# Panel 1: chasis + IMU + LiDAR (bringup) — DIRECTO en la Pi, igual que
# tu Terminal 1 original (no docker).
# ---------------------------------------------------------------------------
tmux new-session -d -s "$SESSION" -n main
tmux send-keys -t "$SESSION:main" \
  "echo '[BRINGUP] chasis + IMU + LiDAR'; sh ~/ros2_humble.sh; $WS_SETUP && ros2 launch yahboomcar_bringup yahboomcar_bringup_launch.py" C-m

sleep 1

# ---------------------------------------------------------------------------
# Panel 2: cámara (usb_cam) — dentro del contenedor de cámara.
# ---------------------------------------------------------------------------
tmux split-window -h -t "$SESSION:main"
tmux send-keys -t "$SESSION:main.1" \
  "echo '[CAMARA] usb_cam'; docker exec -it $CAM_CONTAINER bash -lc '$WS_SETUP && ros2 launch usb_cam camera.launch.py'" C-m

sleep 1

# ---------------------------------------------------------------------------
# Panel 3: código principal del Gran Prix (maze_solver + pare_detector +
# box_detector) — dentro del contenedor principal (antes lane_node.py).
# ---------------------------------------------------------------------------
tmux split-window -v -t "$SESSION:main.0"
tmux send-keys -t "$SESSION:main.2" \
  "echo '[GRAN PRIX] maze_solver + pare_detector + box_detector + dashboard web'; sleep 5; docker exec -it $MAIN_CONTAINER bash -lc '$WS_SETUP && cd ~/yahboomcar_ws && ros2 launch capytown_granprix_pkg granprix.launch.py show_dashboard:=true'" C-m

sleep 1

# ---------------------------------------------------------------------------
# Panel 4: estado de la FSM en vivo (/maze_state) — "terminal de estado".
# ---------------------------------------------------------------------------
tmux split-window -v -t "$SESSION:main.1"
tmux send-keys -t "$SESSION:main.3" \
  "echo '[ESTADO FSM] /maze_state (Ctrl+C aquí NO detiene el robot, solo el echo)'; sleep 9; docker exec -it $MAIN_CONTAINER bash -lc '$WS_SETUP && ros2 topic echo /maze_state'" C-m

tmux select-layout -t "$SESSION:main" tiled

# ---------------------------------------------------------------------------
# Posición de la cámara (servo) — UNA sola vez al arrancar, igual que tu
# "Terminal opcional". No abre panel visible, solo publica y termina.
# ---------------------------------------------------------------------------
tmux new-window -t "$SESSION" -n servo
tmux send-keys -t "$SESSION:servo" \
  "echo '[SERVO] posicionando cámara (s1=$SERVO_S1 s2=$SERVO_S2)...'; sleep 3; \
docker exec -it $SERVO_CONTAINER bash -lc \"$WS_SETUP && ros2 topic pub /servo_s1 std_msgs/msg/Int32 'data: $SERVO_S1' --once && ros2 topic pub /servo_s2 std_msgs/msg/Int32 'data: $SERVO_S2' --once\"; \
echo '[SERVO] listo.'" C-m

# ---------------------------------------------------------------------------
# Ventanas gráficas (se abren solas en el escritorio de RealVNC, aparte de
# tmux): cámara cruda, overlay de detección de PARE, y RViz.
# ---------------------------------------------------------------------------
tmux new-window -t "$SESSION" -n guis
tmux send-keys -t "$SESSION:guis" \
  "echo 'Esperando 12s a que la cámara y el código principal arranquen...'; sleep 12; \
echo '[GUI] cámara cruda (/image_raw)'; \
docker exec -d $CAM_CONTAINER bash -lc '$WS_SETUP && ros2 run rqt_image_view rqt_image_view /image_raw'; \
sleep 2; \
echo '[GUI] overlay de detección de PARE (/pare/debug_image)'; \
docker exec -d $CAM_CONTAINER bash -lc '$WS_SETUP && ros2 run rqt_image_view rqt_image_view /pare/debug_image'; \
sleep 2; \
echo '[GUI] RViz (trayectoria /odom_raw + markers /granprix_markers)'; \
docker exec -d $MAIN_CONTAINER bash -lc '$WS_SETUP && (rviz2 || echo \"rviz2 no está instalado en este contenedor\")'; \
echo; echo 'Listo. Si alguna ventana no aparece, reintenta ese mismo comando docker exec'; \
echo 'SIN el -d (para verlo interactivo y leer el error).'" C-m

tmux select-window -t "$SESSION:main"
echo "==> Dashboard web (LiDAR + recorrido + cámara + pausa/valores): http://$(hostname -I | awk '{print $1}'):8080/"
echo "==> Listo. Adjuntando a la sesión tmux (Ctrl+B luego D para salir sin detener nada)..."
sleep 1
tmux attach -t "$SESSION"
