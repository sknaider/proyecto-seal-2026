# CapyTown Gran Prix — correcciones (FABLE, 13-jul-2026)

Paquete `capytown_granprix_pkg` corregido sobre `capytown_G4_s13`. Qué cambió y cómo usarlo.

## Qué se corrigió

| Problema reportado | Causa | Fix |
|---|---|---|
| No llega a la meta | `meta_enabled: false` | `true` + coords 3.0/2.0 (robot mira a la derecha → meta adelante-izquierda) + radio 0.45 |
| Cámara no ve rojo | `use_attention_gate` bloqueaba salvo en intersección | `false` (analiza siempre) |
| `ros2 launch` revienta en robot limpio | faltaban deps | `python3-opencv/numpy/matplotlib` en package.xml |
| Robot "choca con todo" | `emerg_dist=0.15` (frena a 15cm, tarde) | subido a `0.28` |
| Ver LiDAR + cámara | no estaban en el launch | `lidar_visualizer` + `rqt_image_view` cableados (enable_viz) |
| 2 vueltas / ruta más corta | no existía | control por teclado + recorte de dead-ends (opción A) |

## Cómo correr

```bash
# 1) copiar el paquete a tu workspace y compilar
cp -r capytown_granprix_pkg ~/yahboomcar_ws/src/
cd ~/yahboomcar_ws && colcon build --packages-select capytown_granprix_pkg
source install/setup.bash

# 2) lanzar todo (maze_solver + pare_detector + box_detector + las 2 ventanas de visualizacion)
ros2 launch capytown_granprix_pkg granprix.launch.py

# 3) EN OTRA TERMINAL — control de las 2 vueltas por teclado
ros2 run capytown_granprix_pkg vuelta_keyboard
#   [a] = marcar META (cierra vuelta 1, recorta la ruta)   [s] = iniciar vuelta 2   [q] = salir
```

## Las 2 vueltas (opcion A — ruta mas corta real)

- **Vuelta 1 (exploracion):** el robot navega con wall-following y GRABA su trayectoria.
- Al llegar a la meta presionas **`a`**: se cierra la vuelta y se **recortan los callejones sin salida**
  de la trayectoria -> queda la **ruta mas corta real** (guardada en `/tmp/ruta_optima_granprix.csv`,
  y su longitud alimenta la metrica de eficiencia).
- Presionas **`s`**: arranca la **vuelta 2** (time attack, `ronda=2`).
- El recorte esta verificado por tests (`python3 capytown_granprix_pkg/route_pruning.py` -> 8/8) y por
  integracion (una trayectoria con callejon de 4m queda 27% mas corta).

## A CONFIRMAR POR EFECTO EN TU PISTA (no verificable sin el robot)

1. **Signo de `meta_y`**: si al llegar a la meta el robot NO para, invertí `meta_y` a `-2.0` en el yaml.
2. **Topic de la camara**: si `pare_detector` no recibe imagen, tu camara publica en otro topic —
   `ros2 topic list`, y ajusta `image_topic` en el yaml (suele ser `/camera/image_raw`).
3. **Colisiones al girar (esquinas)**: si con `emerg_dist=0.28` SIGUE rozando las esquinas, amplia
   `front_sector` de 12 a 18-20 en `maze_solver.py` (hay zona ciega diagonal 12°-50°). No lo toque a
   ciegas porque un sector muy ancho puede dar giros falsos — es un ajuste por efecto.
4. **`side`**: si con la mano derecha no encuentra el camino, proba `side:=left`.
