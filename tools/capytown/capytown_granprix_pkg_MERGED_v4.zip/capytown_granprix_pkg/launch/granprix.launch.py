#!/usr/bin/env python3
"""Lanza TODO el software del CapyTown Gran Prix con un solo comando:

    ros2 launch capytown_granprix_pkg granprix.launch.py

Arranca:
  * camera_driver    — usb_cam -> publica /image_raw  [open_camera, default true]  (ALICE 13-jul)
  * maze_solver      — LiDAR wall-following + fusión PARE + métricas + RViz markers + 2 vueltas
  * pare_detector    — cámara -> HSV rojo -> /pare_detectado (+ /pare/debug_image con el PARE marcado)
  * box_detector     — censo de karpinchus (opcional)
  * lidar_visualizer — ventana matplotlib con lo que ve el LiDAR (/scan) [enable_viz]
  * rqt_image_view   — ventana con lo que ve la cámara y el PARE marcado (/pare/debug_image) [enable_viz]

CONTROL DE LAS 2 VUELTAS (por teclado) — correr en su PROPIA terminal (necesita teclado interactivo):
    ros2 run capytown_granprix_pkg vuelta_keyboard
    [a] = marcar META (cierra la vuelta y recorta la ruta)   [s] = iniciar vuelta 2   [q] = salir

CÁMARA (ALICE 13-jul): este launch AHORA arranca el driver usb_cam que publica /image_raw
(antes NO lo hacía → por eso "la cámara no abría"). Si tu robot ya publica /image_raw por su
bringup, desactivá el driver de acá para no duplicar:
    ros2 launch capytown_granprix_pkg granprix.launch.py open_camera:=false
Si tu cámara está en otro /dev/videoN:  open_camera:=true video_device:=/dev/video1
Si usás otro driver (v4l2_camera o el del Yahboom), poné open_camera:=false y arrancalo aparte.

Parámetros finos: config/granprix_params.yaml. Ejemplos de override:
    ros2 launch capytown_granprix_pkg granprix.launch.py side:=left
    ros2 launch capytown_granprix_pkg granprix.launch.py enable_viz:=false
    ros2 launch capytown_granprix_pkg granprix.launch.py meta_enabled:=false
"""
import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch.conditions import IfCondition
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg = get_package_share_directory("capytown_granprix_pkg")
    params_yaml = os.path.join(pkg, "config", "granprix_params.yaml")

    ronda = DeclareLaunchArgument("ronda", default_value="1")
    run_id = DeclareLaunchArgument("run_id", default_value="1")
    side = DeclareLaunchArgument("side", default_value="right")
    # FABLE 13-jul: meta_enabled por defecto TRUE (estaba false = nunca paraba en la meta).
    meta_enabled = DeclareLaunchArgument("meta_enabled", default_value="true")
    meta_x = DeclareLaunchArgument("meta_x", default_value="3.0")
    meta_y = DeclareLaunchArgument("meta_y", default_value="2.0")
    enable_karpinchus = DeclareLaunchArgument("enable_karpinchus", default_value="true")
    # FABLE 13-jul: visualizaciones (LiDAR + cámara). enable_viz:=false para correr sin ventanas.
    enable_viz = DeclareLaunchArgument("enable_viz", default_value="true")
    # ALICE 13-jul: arrancar el DRIVER de cámara (el gap que faltaba). false si el bringup ya publica /image_raw.
    open_camera = DeclareLaunchArgument("open_camera", default_value="true")
    video_device = DeclareLaunchArgument("video_device", default_value="/dev/video0")

    # ALICE 13-jul: DRIVER de cámara (usb_cam) → publica /image_raw, que es lo que el pare_detector
    # espera. Este nodo era el que faltaba: sin él, /image_raw no existe, el visor queda en negro
    # y el pare_detector nunca ve rojo (por más que use_attention_gate=false).
    camera_driver_node = Node(
        package="usb_cam",
        executable="usb_cam_node_exe",
        name="usb_cam",
        output="screen",
        parameters=[{
            "video_device": LaunchConfiguration("video_device"),
            "pixel_format": "yuyv",
            "framerate": 15.0,
        }],
        condition=IfCondition(LaunchConfiguration("open_camera")),
    )

    maze_solver_node = Node(
        package="capytown_granprix_pkg",
        executable="maze_solver",
        name="maze_solver",
        output="screen",
        parameters=[
            params_yaml,
            {
                "ronda": ParameterValue(LaunchConfiguration("ronda"), value_type=int),
                "run_id": ParameterValue(LaunchConfiguration("run_id"), value_type=int),
                "side": LaunchConfiguration("side"),
                "meta_enabled": ParameterValue(LaunchConfiguration("meta_enabled"), value_type=bool),
                "meta_x": ParameterValue(LaunchConfiguration("meta_x"), value_type=float),
                "meta_y": ParameterValue(LaunchConfiguration("meta_y"), value_type=float),
                "enable_obstacle_veer": ParameterValue(
                    LaunchConfiguration("enable_karpinchus"), value_type=bool),
            },
        ],
    )

    pare_detector_node = Node(
        package="capytown_granprix_pkg",
        executable="pare_detector",
        name="pare_detector",
        output="screen",
        parameters=[params_yaml],
    )

    box_detector_node = Node(
        package="capytown_granprix_pkg",
        executable="box_detector",
        name="box_detector",
        output="screen",
        parameters=[params_yaml],
        condition=IfCondition(LaunchConfiguration("enable_karpinchus")),
    )

    # FABLE 13-jul: ventana con lo que VE EL LIDAR (nube 2D del /scan).
    lidar_viz_node = Node(
        package="capytown_granprix_pkg",
        executable="lidar_visualizer",
        name="lidar_visualizer",
        output="screen",
        parameters=[params_yaml],
        condition=IfCondition(LaunchConfiguration("enable_viz")),
    )

    # FABLE 13-jul: ventana con lo que VE LA CÁMARA + el cartel PARE marcado (/pare/debug_image).
    # rqt_image_view es un paquete estándar de ROS2. Si no está instalado, correr con enable_viz:=false
    # y ver la imagen a mano: `ros2 run rqt_image_view rqt_image_view /pare/debug_image`.
    camera_viz_node = Node(
        package="rqt_image_view",
        executable="rqt_image_view",
        name="camera_view",
        arguments=["/pare/debug_image"],
        output="screen",
        condition=IfCondition(LaunchConfiguration("enable_viz")),
    )

    return LaunchDescription([
        ronda, run_id, side, meta_enabled, meta_x, meta_y, enable_karpinchus, enable_viz,
        open_camera, video_device,
        camera_driver_node,
        maze_solver_node, pare_detector_node, box_detector_node,
        lidar_viz_node, camera_viz_node,
    ])
