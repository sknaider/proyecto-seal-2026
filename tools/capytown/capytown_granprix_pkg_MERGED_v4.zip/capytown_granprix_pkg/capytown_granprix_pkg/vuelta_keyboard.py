#!/usr/bin/env python3
"""
Nodo ROS2 para control de teclado del reto CapyTown Gran Prix.
Lee teclas sin necesidad de presionar Enter y publica comandos de control de vueltas.

Uso:
    ros2 run capytown_granprix_pkg vuelta_keyboard

Teclas:
    [a] = marcar META (cierra vuelta actual)
    [s] = iniciar vuelta 2 (time attack)
    [q] = salir del nodo
"""

import sys
import select
import termios
import tty
import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class VueltaKeyboardNode(Node):
    """
    Nodo ROS2 que lee comandos de teclado sin bloqueo y publica en /vuelta_control.
    Utiliza un timer a 10Hz con select.select para lectura no-bloqueante del stdin.
    """

    def __init__(self):
        super().__init__('vuelta_keyboard')

        # Parámetro para el topic de control
        self.declare_parameter('vuelta_control_topic', '/vuelta_control')
        self.topic_name = self.get_parameter('vuelta_control_topic').value

        # Publisher a std_msgs/String con QoS depth 10
        self.publisher = self.create_publisher(String, self.topic_name, 10)

        # Configuración del TTY
        self.settings = None
        self.is_tty = False

        # Intentar configurar el TTY para lectura no-bloqueante
        try:
            if sys.stdin.isatty():
                self.is_tty = True
                self.settings = termios.tcgetattr(sys.stdin)
                tty.setcbreak(sys.stdin.fileno())
                self.get_logger().info("TTY configurado para lectura no-bloqueante")
            else:
                self.get_logger().warn(
                    "vuelta_keyboard necesita un terminal interactivo; "
                    "correlo con: ros2 run capytown_granprix_pkg vuelta_keyboard"
                )
        except Exception as e:
            self.get_logger().warn(f"No se pudo configurar TTY: {e}")

        # Imprimir instrucciones de uso
        self.get_logger().info("[a]=marcar META  [s]=iniciar vuelta 2  [q]=salir")

        # Timer a 10Hz (100ms) para lectura no-bloqueante sin threads
        self.create_timer(0.1, self.timer_callback)

    def timer_callback(self):
        """Callback del timer: intenta leer una tecla sin bloquear."""
        if not self.is_tty:
            return

        # select.select con timeout 0 para chequear disponibilidad sin bloquear
        try:
            ready, _, _ = select.select([sys.stdin], [], [], 0.0)
        except Exception:
            return

        if ready:
            try:
                key = sys.stdin.read(1)
                if key:
                    self.handle_key(key)
            except Exception:
                pass

    def handle_key(self, key):
        """Procesa una tecla y publica el comando correspondiente."""
        if key == 'a':
            msg = String(data="meta")
            self.publisher.publish(msg)
            self.get_logger().info("Publicado: 'meta' (META alcanzada)")
        elif key == 's':
            msg = String(data="vuelta2")
            self.publisher.publish(msg)
            self.get_logger().info("Publicado: 'vuelta2' (iniciando vuelta 2)")
        elif key == 'q':
            self.get_logger().info("Saliendo del nodo...")
            raise KeyboardInterrupt()

    def cleanup(self):
        """Restaura el TTY a su estado original (CRÍTICO: evita terminal roto)."""
        if self.is_tty and self.settings:
            try:
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
                self.get_logger().info("TTY restaurado")
            except Exception:
                pass


def main(args=None):
    """Punto de entrada del nodo."""
    rclpy.init(args=args)
    node = VueltaKeyboardNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        # Garantizar restauración del TTY en cualquier caso de salida
        node.cleanup()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
