"""
Route pruning module for CapyTown: removes dead-end excursions from recorded robot trajectories.

A robot exploring a maze records a trajectory as a list of (x, y) points. This module
identifies and removes spur loops (instances where the robot returned near a previously
visited point after a dead-end exploration) to produce the shortest useful path.

Algorithm: iteratively find points that are close (< tol) to earlier points in the path,
remove the detour between them, and repeat until no more dead-ends are found.
"""

import math
from typing import List, Tuple


def dist(a: Tuple[float, float], b: Tuple[float, float]) -> float:
    """
    Euclidean distance between two 2D points.

    Args:
        a: Point (x, y)
        b: Point (x, y)

    Returns:
        Euclidean distance as float (meters).
    """
    return math.sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2)


def downsample(points: List[Tuple[float, float]], min_step: float = 0.05) -> List[Tuple[float, float]]:
    """
    Remove consecutive points that are too close (< min_step), to clean up dense odometry.
    Preserves the first and last point.

    Args:
        points: List of (x, y) points.
        min_step: Minimum distance between consecutive points (meters). Default 0.05 m.

    Returns:
        Downsampled list of points.
    """
    if len(points) <= 2:
        return points

    downsampled = [points[0]]
    for i in range(1, len(points) - 1):
        if dist(downsampled[-1], points[i]) >= min_step:
            downsampled.append(points[i])
    downsampled.append(points[-1])
    return downsampled


def prune_deadends(
    points: List[Tuple[float, float]],
    tol: float = 0.20,
    min_gap: int = 3
) -> List[Tuple[float, float]]:
    """
    Remove dead-end excursions (spurs) from a trajectory using proximity-based loop removal.

    Algorithm:
    1. Iterate through the path.
    2. For each point i, find the last point j > i such that dist(point[i], point[j]) < tol.
    3. If j - i >= min_gap, remove the segment i+1..j-1 and continue.
    4. Repeat until no more spurs are found.

    Args:
        points: List of (x, y) points representing the robot's path.
        tol: Distance threshold for proximity (meters). Default 0.20 m (~1/3 of 60cm hallway).
        min_gap: Minimum segment length to consider as a spur. Default 3 points.

    Returns:
        Pruned trajectory with dead-end excursions removed.
    """
    if len(points) <= 2:
        return points

    pruned = list(points)

    # Repeatedly scan for spurs until no more are found
    changed = True
    while changed:
        changed = False
        i = 0
        while i < len(pruned) - min_gap:
            # Find the LAST point j > i such that it's close to point i
            j = -1
            for k in range(len(pruned) - 1, i + min_gap - 1, -1):
                if dist(pruned[i], pruned[k]) < tol:
                    j = k
                    break

            if j > 0:
                # Found a spur: remove everything between i and j (keep i and j)
                pruned = pruned[:i+1] + pruned[j:]
                changed = True
                break

            i += 1

    return pruned


def path_length(points: List[Tuple[float, float]]) -> float:
    """
    Calculate the total length of a path as the sum of distances between consecutive points.

    Args:
        points: List of (x, y) points.

    Returns:
        Total path length in meters.
    """
    if len(points) < 2:
        return 0.0

    total = 0.0
    for i in range(len(points) - 1):
        total += dist(points[i], points[i + 1])
    return total


if __name__ == "__main__":
    """
    Test suite: verify pruning correctness via effect.
    """

    tests_passed = 0
    tests_total = 0

    # TEST 1: Straight path without detours → should remain unchanged
    tests_total += 1
    straight_path = [(0.0, 0.0), (1.0, 0.0), (2.0, 0.0), (3.0, 0.0), (4.0, 0.0)]
    pruned = prune_deadends(straight_path)
    if len(pruned) == len(straight_path) and pruned[0] == straight_path[0] and pruned[-1] == straight_path[-1]:
        print("✓ TEST 1 PASS: Straight path preserved")
        tests_passed += 1
    else:
        print(f"✗ TEST 1 FAIL: Expected {len(straight_path)} points, got {len(pruned)}")

    # TEST 2: Single dead-end (goes into a spur and returns to same point) → spur removed
    tests_total += 1
    # Path: go forward, enter dead-end, return to near the entry, continue
    with_spur = [
        (0.0, 0.0),   # Start
        (1.0, 0.0),   # Forward
        (2.0, 0.0),   # Forward
        (2.0, 1.0),   # Enter dead-end (spur starts)
        (2.0, 2.0),   # Deep in spur
        (2.0, 1.0),   # Back toward entry
        (2.0, 0.05),  # Near the entry point (within tol=0.20)
        (3.0, 0.0),   # Continue on main path
        (4.0, 0.0),   # End
    ]
    orig_len = path_length(with_spur)
    pruned = prune_deadends(with_spur, tol=0.20, min_gap=3)
    pruned_len = path_length(pruned)
    if pruned_len < orig_len and pruned[0] == with_spur[0] and pruned[-1] == with_spur[-1]:
        print(f"✓ TEST 2 PASS: Single spur removed (length {orig_len:.2f} → {pruned_len:.2f} m)")
        tests_passed += 1
    else:
        print(f"✗ TEST 2 FAIL: Length not reduced or endpoints changed. Orig: {orig_len:.2f}, Pruned: {pruned_len:.2f}")

    # TEST 3: Two dead-ends → both removed
    tests_total += 1
    # Path: forward, spur1, return, forward, spur2, return, end
    two_spurs = [
        (0.0, 0.0),   # Start
        (1.0, 0.0),   # Forward
        (1.0, 1.0),   # Spur 1 start
        (1.0, 2.0),   # Deep in spur 1
        (1.0, 0.05),  # Back to near start of spur 1
        (2.0, 0.0),   # Continue main
        (3.0, 0.0),   # Forward
        (3.0, -1.0),  # Spur 2 start
        (3.0, -2.0),  # Deep in spur 2
        (3.0, 0.05),  # Back to near start of spur 2
        (4.0, 0.0),   # Continue main
    ]
    orig_len = path_length(two_spurs)
    pruned = prune_deadends(two_spurs, tol=0.20, min_gap=3)
    pruned_len = path_length(pruned)
    if pruned_len < orig_len and len(pruned) < len(two_spurs) and pruned[0] == two_spurs[0] and pruned[-1] == two_spurs[-1]:
        print(f"✓ TEST 3 PASS: Two spurs removed (length {orig_len:.2f} → {pruned_len:.2f} m, points {len(two_spurs)} → {len(pruned)})")
        tests_passed += 1
    else:
        print(f"✗ TEST 3 FAIL: Length not reduced or endpoints changed. Orig: {orig_len:.2f}, Pruned: {pruned_len:.2f}")

    # TEST 4: Edge cases (empty, 1 point, 2 points) → no crash
    tests_total += 1
    try:
        empty = prune_deadends([])
        one_pt = prune_deadends([(1.0, 1.0)])
        two_pts = prune_deadends([(0.0, 0.0), (1.0, 1.0)])

        if len(empty) == 0 and len(one_pt) == 1 and len(two_pts) == 2:
            print("✓ TEST 4 PASS: Edge cases handled (empty, 1 point, 2 points)")
            tests_passed += 1
        else:
            print(f"✗ TEST 4 FAIL: Edge case sizes incorrect: empty={len(empty)}, one={len(one_pt)}, two={len(two_pts)}")
    except Exception as e:
        print(f"✗ TEST 4 FAIL: Exception during edge case handling: {e}")

    # TEST 5: Path length monotonicity → pruned path always <= original
    tests_total += 1
    complex_path = [
        (0.0, 0.0), (1.0, 0.0), (2.0, 0.0), (2.0, 1.0), (2.0, 2.0), (2.0, 0.1),
        (3.0, 0.0), (4.0, 0.0), (4.0, -1.0), (4.0, -2.0), (4.0, 0.0), (5.0, 0.0)
    ]
    orig_len = path_length(complex_path)
    pruned = prune_deadends(complex_path, tol=0.20, min_gap=3)
    pruned_len = path_length(pruned)
    if pruned_len <= orig_len + 1e-6:  # Allow tiny float error
        print(f"✓ TEST 5 PASS: Path length monotonic (pruned <= original: {pruned_len:.2f} <= {orig_len:.2f})")
        tests_passed += 1
    else:
        print(f"✗ TEST 5 FAIL: Pruned path longer than original! {pruned_len:.2f} > {orig_len:.2f}")

    # TEST 6: First and last points always preserved
    tests_total += 1
    messy_path = [
        (0.0, 0.0), (1.0, 0.0), (1.5, 1.0), (1.0, 1.5), (0.1, 0.0), (2.0, 0.0),
        (3.0, 0.0), (3.0, 1.0), (3.0, 0.05), (4.0, 0.0), (5.0, 5.0)
    ]
    pruned = prune_deadends(messy_path, tol=0.20, min_gap=3)
    if pruned[0] == messy_path[0] and pruned[-1] == messy_path[-1]:
        print(f"✓ TEST 6 PASS: First and last points preserved")
        tests_passed += 1
    else:
        print(f"✗ TEST 6 FAIL: Endpoints not preserved. Start: {pruned[0]} vs {messy_path[0]}, End: {pruned[-1]} vs {messy_path[-1]}")

    # TEST 7: Downsample function works
    tests_total += 1
    dense_path = [
        (0.0, 0.0), (0.02, 0.0), (0.04, 0.0), (0.06, 0.0),
        (1.0, 0.0), (1.02, 0.0), (2.0, 0.0)
    ]
    downsampled = downsample(dense_path, min_step=0.05)
    if len(downsampled) < len(dense_path) and downsampled[0] == dense_path[0] and downsampled[-1] == dense_path[-1]:
        print(f"✓ TEST 7 PASS: Downsample reduces dense path ({len(dense_path)} → {len(downsampled)} points)")
        tests_passed += 1
    else:
        print(f"✗ TEST 7 FAIL: Downsample didn't work as expected")

    # TEST 8: dist function is correct
    tests_total += 1
    d = dist((0.0, 0.0), (3.0, 4.0))
    if abs(d - 5.0) < 1e-6:
        print(f"✓ TEST 8 PASS: dist(0,0 → 3,4) = {d:.2f} (expected 5.0)")
        tests_passed += 1
    else:
        print(f"✗ TEST 8 FAIL: dist calculation wrong: {d} != 5.0")

    # Summary
    print("\n" + "="*60)
    print(f"RESULTS: {tests_passed}/{tests_total} tests PASSED")
    print("="*60)

    if tests_passed == tests_total:
        print("✓ All tests passed!")
    else:
        print(f"✗ {tests_total - tests_passed} test(s) failed")
