@echo off
REM SEAL Remote - Windows Configuration
REM Sets up RustDesk to use SEAL relay server
REM Run ONCE after installing RustDesk

SET RELAY_HOST=100.75.201.110
SET RELAY_KEY=mF4R9fb4B+j5DEmhKnGdwROsStnmTvHZtd9jyXNtXgw=
SET CONFIG_DIR=%APPDATA%\RustDesk\config

IF NOT EXIST "%CONFIG_DIR%" MKDIR "%CONFIG_DIR%"

REM Write RustDesk2.toml with SEAL relay
(
echo rendezvous_server = '%RELAY_HOST%:21116'
echo nat_type = 1
echo serial = 0
echo unlock_pin = ''
echo trusted_devices = ''
echo.
echo [options]
echo custom-rendezvous-server = '%RELAY_HOST%'
echo relay-server = '%RELAY_HOST%'
echo key = '%RELAY_KEY%'
) > "%CONFIG_DIR%\RustDesk2.toml"

echo [SEAL Remote] Configuracion aplicada: %RELAY_HOST%
echo Ahora abre RustDesk. Tu ID aparece en la pantalla principal.
echo Comparte ese ID con el equipo SEAL para acceso remoto.
pause
