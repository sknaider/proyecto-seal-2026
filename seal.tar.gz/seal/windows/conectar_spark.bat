@echo off
REM SEAL Remote — Conectar directo a DGX Spark
REM Requiere RustDesk instalado en Windows
REM ID Spark: 125840607 | Clave: seal2026

SET SPARK_ID=125840607
SET RELAY_HOST=100.75.201.110
SET CONFIG_DIR=%APPDATA%\RustDesk\config

REM Aplicar config del relay SEAL si no existe
IF NOT EXIST "%CONFIG_DIR%\RustDesk2.toml" (
    call "%~dp0configure_seal_remote.bat"
)

REM Conectar directamente a Spark
echo Conectando a DGX Spark (ID: %SPARK_ID%)...
echo Clave: seal2026
start "" "C:\Program Files\RustDesk\rustdesk.exe" --connect %SPARK_ID% --password seal2026 2>nul || ^
start "" "%LOCALAPPDATA%\Programs\RustDesk\rustdesk.exe" --connect %SPARK_ID% --password seal2026 2>nul || ^
start "" rustdesk.exe --connect %SPARK_ID% --password seal2026 2>nul

echo Listo. Si RustDesk no abrio automaticamente, abrelo manualmente e ingresa ID: %SPARK_ID%
timeout /t 3
