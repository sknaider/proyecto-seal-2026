#!/usr/bin/env python3
"""SEAL Windows Installer --- one script, two commands.

Usage:
    # 1. Download from Spark:
    #    curl http://192.168.68.80:8899/windows_install.py -o install.py
    # 2. Run:
    #    python install.py --profile laptop --agent JARVIS

Creates:
    USERPROFILE/.seal/profiles/<name>/config.toml
    USERPROFILE/.seal/profiles/<name>/db_url.env
    seal_start.bat  (run this to start SEAL)

No external dependencies --- stdlib only.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

_DB_DEFAULT = "postgresql://seal:seal_memory_2026@192.168.68.80:5433/seal_memory"
_SEAL_VERSION = "0.1.0"


def _find_claude() -> str | None:
    """Locate the claude binary on Windows."""
    import shutil

    found = shutil.which("claude")
    if found:
        return found
    candidates = [
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "claude" / "claude.exe",
        Path(os.environ.get("APPDATA", "")) / "npm" / "claude.cmd",
        Path(os.environ.get("APPDATA", "")) / "npm" / "claude",
        Path.home() / ".local" / "bin" / "claude",
        Path("C:/Program Files/claude/claude.exe"),
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return None


def _write_config(pdir: Path, name: str, agent: str) -> None:
    config = f"""[agent]
name = "{agent}"
display_name = "{agent} — SEAL"
profile = "{name}"
version = "{_SEAL_VERSION}"

[ocean]
O = 0.83
C = 1.0
E = 0.4
A = 0.66
N = 0.12

[model]
primary = "claude-sonnet-4-6"
fallback = "claude-haiku-4-5-20251001"
local_endpoint = ""

[channels]
webchat_port = 8765

[rules]
language = "es"
timezone = "America/Lima"
"""
    (pdir / "config.toml").write_text(config, encoding="utf-8")


def _write_env(pdir: Path, name: str, db_url: str) -> None:
    schema = f"soul_v3_{name}"
    (pdir / "db_url.env").write_text(
        f"SEAL_SCHEMA={schema}\nSEAL_DB_URL={db_url}\n", encoding="utf-8"
    )


def _write_bat(install_root: Path, profile_name: str, agent: str, db_url: str,
               claude_bin: str | None) -> Path:
    schema = f"soul_v3_{profile_name}"
    bat_path = install_root / "seal_start.bat"

    claude_line = f'"{claude_bin}" --name {agent}' if claude_bin else (
        "echo ERROR: claude binary not found. Install Claude CLI first.\npause\nexit /b 1"
    )

    content = f"""@echo off
title SEAL — {agent} [{profile_name}]
setlocal

set SEAL_AGENT={agent}
set SEAL_PROFILE={profile_name}
set SEAL_SCHEMA={schema}
set SEAL_DB_URL={db_url}
set SEAL_ROOT=%~dp0

echo Starting SEAL {agent} (profile: {profile_name})...
{claude_line}
"""
    bat_path.write_text(content, encoding="utf-8")
    return bat_path


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="SEAL Windows Installer")
    ap.add_argument("--profile", default="laptop", help="Profile name [laptop]")
    ap.add_argument("--agent", default="JARVIS", help="Agent name [JARVIS]")
    ap.add_argument("--db-url", default=_DB_DEFAULT,
                    help=f"PostgreSQL URL [{_DB_DEFAULT}]")
    args = ap.parse_args(argv)

    seal_home = Path(os.environ.get("SEAL_HOME", Path.home() / ".seal"))
    profile_dir = seal_home / "profiles" / args.profile
    install_root = Path(__file__).resolve().parent.parent

    print(f"SEAL installer v{_SEAL_VERSION}")
    print(f"  profile : {args.profile}")
    print(f"  agent   : {args.agent}")
    print(f"  db      : {args.db_url}")
    print()

    # Create profile directory
    (profile_dir / "logs").mkdir(parents=True, exist_ok=True)
    _write_config(profile_dir, args.profile, args.agent)
    _write_env(profile_dir, args.profile, args.db_url)
    print(f"✓ profile created at {profile_dir}")

    # Find claude binary
    claude_bin = _find_claude()
    if claude_bin:
        print(f"✓ claude found: {claude_bin}")
    else:
        print("⚠ claude not found — install from https://claude.ai/download")
        print("  The launcher will be created but won't work until claude is installed.")

    # Write launcher
    bat = _write_bat(install_root, args.profile, args.agent, args.db_url, claude_bin)
    print(f"✓ launcher created: {bat}")
    print()
    print("─" * 50)
    print(f"  To start SEAL:  double-click  seal_start.bat")
    print(f"  Or from cmd:    seal_start.bat")
    print("─" * 50)

    return 0


if __name__ == "__main__":
    sys.exit(main())
